

<?php $__env->startSection('conteudo'); ?>
<div class="container">
    <div class="cabecalho">
        <h1 id="cabecalho">CONHECIMENTOPREMIUM</h1>
        <button class="toggle-btn" onclick="toggleMode()" id="btn">Alterar plano de fundo</button>
    </div>
    <div id="cabecalhoLogin">
        <h1 id="cabcalhoLogin1">Pagina de Cadastro</h1>
        <form action="/Comentarios">
            <h2>Por favor insira email:</h2>
            <input type="text" id="email-input" placeholder="guilher@gmail.com">
            <h2>Por favor insira senha:</h2>
            <div class="password-container">
                <input type="password" id="passwordField" placeholder="Digite sua senha">
                <span class="toggle-password" onclick="togglePassword()">&#128065;</span>
            </div>
            <button onclick="login()">fazer login</button>
        </form>
    </div>
    <a href="/">Login</a>
</div>

<div class="cabecalhoo">
    <p id="pconhecimento">CONHECIMENTOPREMIUM</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Cotemig\SiteMeuuu\resources\views/Cadastro.blade.php ENDPATH**/ ?>