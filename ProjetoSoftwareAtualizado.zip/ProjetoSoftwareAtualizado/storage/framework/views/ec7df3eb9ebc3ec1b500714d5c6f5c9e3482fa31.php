

<?php $__env->startSection('conteudo'); ?>
<body class="container">
    <div class="image-container">
        <h1 class="materiad"> Matérias disponivéis no nosso site:</h1>
     <div class="container-display">
        <div class="div">
            <img  src="https://abrir.link/RLnRO" alt="" class="hover-image" >
        </div>
        <div class="div">
            <img  src="https://encurtador.com.br/bC1Uj" alt="" class="hover-image">
        </div>
        <div class="div">
            <img  src="https://encurtador.com.br/w1yPW" alt="" class="hover-image">
        </div>
       <div class="div">
            <img src="https://encurtador.com.br/uUkxW" alt="" class="hover-image">
       </div>
    
       
     </div>
       
    </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Cotemig\site\SiteMeuuu\resources\views/Conteudos.blade.php ENDPATH**/ ?>